# Paraphrasing Project

A simple project to demonstrate paraphrasing functionality using a frontend and backend.